package com.dicoding.picodiploma.mylistview

data class Hero(
    var photo: Int,
    var name: String,
    var description: String
)